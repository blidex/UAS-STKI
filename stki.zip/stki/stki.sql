-- phpMyAdmin SQL Dump
-- version 5.0.4
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Dec 18, 2020 at 03:54 PM
-- Server version: 10.4.17-MariaDB
-- PHP Version: 8.0.0

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `stki`
--

-- --------------------------------------------------------

--
-- Table structure for table `berita`
--

CREATE TABLE `berita` (
  `id` int(5) NOT NULL,
  `judul` tinytext NOT NULL,
  `isi` text NOT NULL,
  `url` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `berita`
--

INSERT INTO `berita` (`id`, `judul`, `isi`, `url`) VALUES
(1, 'Tak Lagi Disukai Pemain Man United, Bruno Fernandes Angkat Kaki dari Old Trafford?', 'sejumlah pemain senior Man Unted tak menyukai Bruno Fernandes karena terlalu vokal di ruang ganti Setan Merah.\'', 'https://bola.okezone.com/read/2020/10/19/45/2295787/tak-lagi-disukai-pemain-man-united-bruno-fernandes-angkat-kaki-dari-old-trafford\')'),
(2, 'mengintip latihan perdana cavani di Manchester united', '‘Karantina mandiri harus dijalani Cavani, setelah tidak mendapat dispensasi sebagai atlet karena dilepas PSG. Selain itu, pemain yang punya catatan 353 gol di level klub sepanjang kariernya itu sempat positif corona pada saat jeda pandemi.', 'https://sport.detik.com/sepakbola/liga-inggris/d-5218996/mengintip-latihan-perdana-edinson-cavani-di-manchester-united'),
(3, 'PSG Tim Bagus, Namun Manchester United Bisa Bicara Banyak di Paris', ' Di laga ini, PSG lebih diunggulkan ketimbang United. Maklum, performa Setan Merah masih belum stabil sementara PSG tampil cukup solid belakangan ini.', 'https://www.bola.net/champions/psg-tim-bagus-namun-manchester-united-bisa-bicara-banyak-di-paris-1e8c7e.html'),
(4, 'Barcelona Akhirnya Lepas Lionel Messi ke Manchester City', 'julukan Lionel Messi– dapat hengkang ke klub mana pun secara gratis pada bursa transfer musim panas 2021. Namun, manajemen Barcelona berharap Manchester City yang jadi pelabuhan Lionel Messi selanjutnya. Setidaknya ada dua alasan yang melatarbelakanginya.', 'https://bola.okezone.com/read/2020/10/19/51/2295769/barcelona-akhirnya-lepas-lionel-messi-ke-manchester-city'),
(5, 'Jelang PSG Vs Man United, Kylian Mbappe Tantang Edinson Cavani', '\'Cavani baru saja bergabung dengan Manchester United pada awal musim ini dengan status bebas transfer', 'https://www.bolasport.com/read/312388513/jelang-psg-vs-man-united-kylian-mbappe-tantang-edinson-cavani'),
(6, 'Buka-Bukaan! Morgan Schneiderlin Preteli Borok Louis Van Gaal Di Manchester United', 'Dia menyebut, juru taktik berkebangsaan Belanda itu punya gaya melatih yang super ketat dan cenderung memaksakan kehendak, sehingga para pemain merasa tertekan ketika bermain. Schneiderlin merasakan betul pengalaman ini. Dia mengaku tak bisa mengeluarkan insting dia.', 'https://www.goal.com/id/berita/morgan-schneiderlin-louis-van-gaal-manchester-united/1s1w1d3lznnps195vbi91sixg1'),
(7, '‘Manchester United Bekuk Newcastle, Solskjaer Soroti Performa Daniel James ', 'Di akhir pekan kemarin, United bertandang ke markas Newcastle. Di laga ini, Solskjaer memberikan kesempatan bagi Daniel James menjadi starter di sektor sayap kiri setelah Marcus Rashford digeser menjadi striker tengah menggantikan Anthony Martial yang mendapatkan suspensi.', 'https://www.bola.net/inggris/manchester-united-bekuk-newcastle-solskjaer-soroti-performa-daniel-james-ed71e9.html'),
(8, '5 Pesepakbola Amerika Selatan yang Sukses di Manchester United', 'Manchester United jarang menjadi salah satu tujuan favorit pemain asal Amerika Selatan. Sejak dimulainya Liga Inggris era Premier League pada 1992, hanya tujuh belas pemain dari Amerika Latin yang pernah bermain untuk Setan Merah. Pada 2001, Man United memiliki pemain asal Amerika Selatan pertama, yakni Juan Sebastian Veron yang datang dari Lazio.', 'https://bola.okezone.com/read/2020/10/19/51/2295891/5-pesepakbola-amerika-selatan-yang-sukses-di-manchester-united'),
(9, 'Pemain Man United Sengaja Tampil Buruk, Solskjaer Alami Nasib seperti Mourinho', 'Hasil buruk yang didapatkan Man United merupakan hal disengaja? Performa buruk sengaja ditunjukkan pemain Man United supaya Solskjaer didepak dari kursi pelatih Man United?', 'https://bola.okezone.com/read/2020/10/14/45/2293668/pemain-man-united-sengaja-tampil-buruk-solskjaer-alami-nasib-seperti-mourinho'),
(10, 'Mumpung Gratis, 3 Pemain Ini Bisa Dicomot Manchester United', ' Donny van de Beek menjadi rekrutan pertama MU pada bursa transfer musim panas. Gelandang asal Belanda itu diboyong dari Ajax Amsterdam dengan biaya 40 juta pounds.', 'https://www.bola.net/editorial/mumpung-gratis-3-pemain-ini-bisa-dicomot-manchester-united-811679.html'),
(11, 'Manchester United Bekuk Newcastle, Solskjaer Soroti Performa Daniel James', 'United bertandang ke markas Newcastle. Di laga ini, Solskjaer memberikan kesempatan bagi Daniel James menjadi starter di sektor sayap kiri setelah Marcus Rashford digeser menjadi striker tengah menggantikan Anthony Martial yang mendapatkan suspensi.', 'https://www.bola.net/inggris/manchester-united-bekuk-newcastle-solskjaer-soroti-performa-daniel-james-ed71e9.html'),
(12, 'PSG vs Manchester United: Kylian Mbappe Kirim Pesan Buat Edinson Cavani', 'Belum lagi dengan fakta bahwa Cavani pernah memperkuat PSG selama tujuh musim. Sudah jelas kalau striker berdarah Uruguay tersebut mengenal Les Parisiens dari luar maupun dalamnya', 'https://www.bola.net/champions/psg-vs-manchester-united-kylian-mbappe-kirim-pesan-buat-edinson-cavani-06834d.html'),
(13, 'Andai Juan Mata Inti, Bagaimana Starting XI Manchester United untuk Lawan PSG?', 'Juan Mata dimainkan sebagai pemain inti saat United berjumpa Newcastle di pekan kelima Premier League (18/10/2020). Juan Mata bermain sebagai winger kanan, menggantikan Mason Greenwood', 'https://www.bola.net/champions/andai-juan-mata-inti-bagaimana-starting-xi-manchester-united-untuk-lawan-psg-196cb4.html'),
(14, 'Paul Pogba Ingin Pindah ke Real Madrid, Manchester United Minta Tukar Fede Valverde?', 'Masa depan Paul Pogba belakangan kembali menjadi bahan spekulasi. Situasi yang sama terjadi pada akhir musim 2018/2019 lalu, ketika dia menyatakan hendak pindah dari Old Trafford', ' https://www.bola.net/inggris/paul-pogba-ingin-pindah-ke-real-madrid-manchester-united-minta-tukar-fede-valverde-5a7d53.html'),
(15, 'Manchester United Bidik Pemain Muda Portugal Berjuluk \'The New Luis Figo', 'Manchester United cukup akrab dengan talenta asal Portugal. Di masa lalu, ada dua nama pemain asal Portugal yang cukup familiar di United yakni Cristiano Ronaldo dan Nani', 'https://www.bola.net/inggris/manchester-united-bidik-pemain-muda-portugal-berjuluk-the-new-luis-figo-0b78bf.html'),
(16, 'elesai Isolasi, Cavani Mulai Latihan Perdana Bersama Man United', 'Sebagaimana diketahui, Edinson Cavani digaet Man United secara gratis pada musim panas 2020. Pemain berusia 33 tahun itu diikat dengan kontrak selama setahun plus opsi perpanjangan otomatis. Peresmian tersebut diumumkan tepat pada penutupan bursa transfer musim panas 2020, 5 Oktober lalu', 'https://bola.okezone.com/read/2020/10/19/45/2295685/selesai-isolasi-cavani-mulai-latihan-perdana-bersama-man-united'),
(17, 'Gagal Total di MU, Pemain Ini Mengeluh Terlalu Dikekang Louis van Gaal', 'Manchester United merekrut Schneiderlin dari Southampton pada musim panas 2015 silam dengan biaya transfer yang ditaksir berkisar di angka 25 juta poundsterling', 'https://www.bola.net/inggris/gagal-total-di-mu-pemain-ini-mengeluh-terlalu-dikekang-louis-van-gaal-5b77d4.html'),
(18, 'Terungkap, MU Sempat Ingin Rekrut Martin Odegaard dari Real Madrid, tapi Gagal', 'Odegaard sejatinya merupakan incaran Manchester United sejak lama. Namun, upaya Setan Merah untuk memboyong pemain Norwegia itu ke Old Trafford selalu tak membuahkan hasil', 'https://www.bola.net/inggris/terungkap-mu-sempat-ingin-rekrut-martin-odegaard-dari-real-madrid-tapi-gagal-8c2f71.html'),
(19, 'Jawaban atas Masalah Lini Belakang Manchester United: Scott McTominay?', 'Kepercayaan diri Harry Maguire tengah runtuh belakangan ini lantaran diterpa berbagai macam permasalahan. Terutama setelah dirinya mendapatkan kartu merah kala memperkuat Timnas Inggris melawan Denmark di UEFA Nations League', 'https://www.bola.net/inggris/jawaban-atas-masalah-lini-belakang-manchester-united-scott-mctominay-e1150b.html’’)'),
(20, 'Petinggi Dortmund Tegaskan Siap Lepas Jadon Sancho ke Manchester United', 'Sesaat setelah jendela transfer ditutup, direktur olahraga Dortmund, Michael Zorc mengakui bahwa Sancho akan diizinkan pergi dari Signal Iduna Park jika ada klub yang bersedia menebus banderol yang mereka tetapkan.', 'https://www.bola.net/bundesliga/petinggi-dortmund-tegaskan-siap-lepas-jadon-sancho-ke-manchester-united-asal-c8c16e.html”)');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `berita`
--
ALTER TABLE `berita`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `berita`
--
ALTER TABLE `berita`
  MODIFY `id` int(5) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=22;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
